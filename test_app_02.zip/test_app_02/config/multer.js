import multer from "multer";

// Multer storage (save files and maintain extension)
const storage = multer.diskStorage({
    destination: 'uploads', 
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '_' + Date.now() + '_' + file.originalname);
    }
});

// File size limitations (1MB here)
export const upload = multer({
    storage,
    limits: {
        fileSize: 1024 * 1024 
    }
});

// Controller for handling multiple fields
export const uploadController = [
    upload.fields([
        { name: 'profilePic', maxCount: 1 },
        { name: 'gallery', maxCount: 5 }
    ]),
    (req, res) => {
        // Uploaded files info
        console.log(req.files.profilePic); // array with 1 file
        console.log(req.files.gallery);    // array with up to 5 files

        res.json({
            message: "Files uploaded successfully",
            files: req.files
        });
    }
];
