import db from './db.js';
import bcrypt from 'bcryptjs';

// Fetch all users (already existing)
export const getUsers = (req,res)=>{
    db.query("SELECT * FROM users",(err,results)=>{
        if(err){
            return res.status(500).json(err);
        }
        res.json(results);
    });
};

// Sign up new user
export const signUpController = (req, res) => {
    const { name, email, phone, password, role } = req.body;

    // Validate request body
    if (!name || !email || !password || !role) {
        return res.status(400).json({ message: "Name, email, password, and role are required" });
    }

    // Hash password
    const hashedPassword = bcrypt.hashSync(password, 10);

    // Insert user into database
    const sql = "INSERT INTO users (name, email, phone, password, role, status) VALUES (?, ?, ?, ?, ?, 'ACTIVE')";
    const values = [name, email, phone || null, hashedPassword, role.toUpperCase()];

    db.query(sql, values, (err, results) => {
        if (err) {
            // Handle duplicate email error
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(409).json({ message: "Email already exists" });
            }
            return res.status(500).json(err);
        }

        res.status(201).json({
            message: "User registered successfully",
            userId: results.insertId
        });
    });
};
