import express from 'express'
import router from './router.js'
import { uploadController } from './config/multer.js'


const app = express()
app.use(express.json())
app.use(express.urlencoded({ extended: true }));

const port = 3000

app.use('/',router)

//set ejs as the view engine
app.set('view engine','ejs')

app.post('/upload', uploadController)

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});