import express from 'express'
import { getUsers, signUpController } from './controller.js'
import { login } from './authController.js'

const router = express.Router()

//test route--http://localhost:3000/
router.get('/',(req,res)=>{
    res.send("System is working + Mysql is working")
})

//fetch all users--http://localhost:3000/users
router.get('/users',getUsers)

//handle login(render signup)--http://localhost:3000/login
router.get('/signup', (req, res) => {
    res.render('signup');
});

//handling invalid urls
router.get('/*any',(req,res)=>{
    res.send("Oops!! You'are trying to reach Invalid URL")
})

router.post('/users', signUpController)
export default router;